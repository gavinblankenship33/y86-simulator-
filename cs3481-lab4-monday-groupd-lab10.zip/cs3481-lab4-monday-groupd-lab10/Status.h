#define SAOK 1
#define SADR 2
#define SINS 3
#define SHLT 4
