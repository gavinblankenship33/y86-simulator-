
//global debug flag
//use to output debugging information
extern int debug;
